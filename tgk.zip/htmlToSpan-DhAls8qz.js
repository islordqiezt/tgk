function t(n){const e=document.createElement("span");return typeof n=="string"?e.innerHTML=n:e.append(n),e}export{t as h};
//# sourceMappingURL=htmlToSpan-DhAls8qz.js.map
