An early version of Video Chats is available in all groups and channels – with a polished design exclusively for Web:

• Expand to view your video chats in fullscreen. 
• Try the wide mode, which shows video feeds side-by-side. 
• Resize and place the video layout on any part of the screen.
• Minimize the window and the app will remember its precious size and position. 
• Mute or leave the video chat from the interactive header.
